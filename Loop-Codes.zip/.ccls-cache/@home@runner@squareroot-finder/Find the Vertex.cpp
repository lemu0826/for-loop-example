#include <iostream>
#include <cmath>

using namespace std; 

int main() {

  double a, b, c;

  cout << "Enter 3 numbers: ";
  cin >> a >> b >> c;

  double vertex_x = -b / (2 * a);
double vertex_y = (4*a*c - b*b) / (4*a);
  cout << "The vertex is (" << vertex_x << "," << vertex_y << ")" << endl;

  return 0;
}