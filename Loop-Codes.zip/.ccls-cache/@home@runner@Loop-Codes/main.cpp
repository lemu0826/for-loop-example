#include <iostream>
using namespace std;
// new library

#include <cmath> //math functions

int main () {
/*/
for(int i = 1; i <= 5; i++){
cout << i << " "; }

  for (int j = 1; j <=2; j++){
    cout << "Hellow  " << endl; 
  }
  for (int k = 2; k <= 20; k+=2){

cout << k << endl; 

}
int sum = 0; 

  for (int l = 1; l<= 100; l++){
sum += l; 
  }
cout << sum << endl; 
*/
  

// 1. Print number form 1-1000 every 10

  for(int m = 0; m <= 1000; m+=10){ 
    cout << m << endl;  }

  
  // 2. Display your name, however many years old you are

 
  for(int l = 1; l <= 17; l++){
cout << "Lupe" << endl;  }
  //3. Print backwards 10-1

for(int n = 10; n >=1; n--){

  cout << n << endl;   
}
  
  
  //4. Print the multiplication table of 5

for (int k = 0; k <= 50; k+= 5){
  cout << k << endl; 
}

for (int i = 1; i <= 10; i++){
  cout << 5 * i << endl;
}


  
  
  return 0; 
}







/*/
int main() {
int number; 
  cout << "Enter a number to check if it is positive or negative: "; 
cin >> number; 
  if(number > 0) {
cout << "The number is positive"; 
  }
else if (number < 0) {
cout << "The number is negative"; 
}
else {
 cout << "The number is zero";
}
 cout


  
  return 0; 
}
*/
























/*/
int main() {
  int grade;

  cout << "Enter your grade: ";
  cin >> grade;

  if (grade >=80) {
    cout << "Good job";
  }

  if (grade <=79 && grade >=61) {
    cout << "Office hours visits are recommended";
  }
  
  if (grade <= 60) {
    cout << "Visiting me after class is an utmost necessity";
  }
  
  return 0;
  */



/*/
int main(){
  string name;

  double a, b, c;

  cout << "Enter username";
  cin >> name;

  cout << " Enter 3 numbers: ";
  cin >> a >> b >> c;

  double discriminant = b*b - 4*a*c;

  if (discriminant > 0){

  double result1 = (-b + sqrt(discriminant)) / (2*a);
  double result2 = (-b - sqrt(discriminant)) / (2*a);


  cout << " Based off the variables A, B, C entered by " << name << " the roots
are " << result1 << " and " << result2 << endl;

  if (discriminant == 0) {

    double root = -b / (2 * a);


cout << "Roots are real and same. Discriminant is 0." << endl;
    cout << "Root is " << root << endl;
 if (discriminant < 0){
double realpart = -b / (2 * a);
double imaginarypart = sqrt(-discriminant) / (2 * a);
      cout << "Roots are complex and different." << endl;
      cout << "Root 1 is " << realpart << "+" << imaginarypart << "i" << endl;
 }


  return 0;
   
}
 */
// Example: Power
/*/int main() {

  double a, b, c;

  cout << "Enter 3 numbers: ";
  cin >> a >> b >> c;

  double vertex_x = -b / (2 * a);
double vertex_y = (4*a*c - b*b) / (4*a);
  cout << "The vertex is (" << vertex_x << "," << vertex_y << ")" << endl;

  return 0;
}
*/
// Example: Power
/*int main() {

using namespace std; 
//declare variable
double number; 
double x = 9, y = 2;



number = pow(x, y);

  cout << "The power of " << x << " to the " << y << " is " << number << endl; 
  
//hardcode the result

double resultOfSquare = sqrt(number); 

//display answer

cout <<  "The square root of "  <<   number  << " is " <<  resultOfSquare  << 
 endl;

return 0;  
}
*/